<?php 
session_start();
 include("inculdes/connection.php");
?>
<?php include("inculdes/header.php") ?>
<br/><br/><br/><br/>
<div class="container-fluid">
  <div class="row justify-content-around">
    <div class="col-8">
      <div class="info">
        <?php include ("inculdes/page_info.php"); ?>
      </div>
    </div>
  </div>
</div>
<br/>
<?php include("inculdes/footer.php") ?>

     