<?php session_start();
	require_once("inculdes/connection.php");
	include("inculdes/header.php");
?>
<br/><br/><br/><br/><br/>
<div class="container">
	<div class="col-12">
    		<div class="row">
    			<?php include("inculdes/page_info.php"); ?>


    		</div>
 </div>
</div>
<br/>
<?php include("inculdes/footer.php"); ?>