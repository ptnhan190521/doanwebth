<?php session_start(); ?>
<?php
 include('includes/permission.php');
 include('includes/connection.php');
 include('includes/header.php'); ?>

<?php
	include('functions/config.php'); 
?>



<?php include('includes/footer.php') ?>