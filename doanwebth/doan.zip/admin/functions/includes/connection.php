<!-- <q></q><?php
	$username  = "root";
	$password  = "";
	$localhost = "localhost";
	$database  = "qlsanpham";

	$con = mysqli_connect($localhost, $username, $password, $database) or die ("Không thể kết nối đến database");
	mysqli_query($con,"SET NAMES 'UTF8'");
 ?> -->